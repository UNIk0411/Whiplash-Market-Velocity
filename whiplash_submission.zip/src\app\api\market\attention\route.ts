import { NextRequest, NextResponse } from 'next/server';
import { AttentionQueueService } from '@/services/attention/queue-service';

export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams;
    const watchlistId = searchParams.get('watchlistId') || undefined;
    const userId = searchParams.get('userId') || 'user_demo_1';

    const feed = await AttentionQueueService.getAttentionFeed(userId, watchlistId);
    return NextResponse.json(feed);
  } catch (error: any) {
    return NextResponse.json(
      { error: 'Failed to fetch attention feed', message: error?.message || 'Unknown error' },
      { status: 500 }
    );
  }
}
