import { MarketDataProvider } from './provider-interface';
import { MarketObservation } from './types';

export class MockMarketDataProvider implements MarketDataProvider {
  private static mockData: Record<string, Omit<MarketObservation, 'symbol'>> = {
    NVDA: {
      companyName: 'NVIDIA Corporation',
      sector: 'Semiconductors',
      price: 128.45,
      change: 5.88,
      changePercent: 4.8,
      volume: 78500000,
      avgVolume: 32700000, // 2.4x baseline volume!
      volatility: 2.1, // normal daily stddev % is 2.1% -> 4.8% move is >2x volatility!
      high: 129.10,
      low: 123.00,
      open: 123.50,
      marketReturn: 0.4,
      sectorReturn: 1.0,
      source: 'Nasdaq Realtime (Mock)',
      freshness: 'LIVE',
      confidence: 0.98,
      observedAt: new Date().toISOString(),
    },
    AMD: {
      companyName: 'Advanced Micro Devices',
      sector: 'Semiconductors',
      price: 142.10,
      change: -5.45,
      changePercent: -3.7,
      volume: 62000000,
      avgVolume: 32600000, // 1.9x volume!
      volatility: 1.8,
      high: 148.50,
      low: 141.80,
      open: 147.90,
      marketReturn: 0.4,
      sectorReturn: 1.0,
      source: 'Nasdaq Realtime (Mock)',
      freshness: 'LIVE',
      confidence: 0.95,
      observedAt: new Date().toISOString(),
    },
    AAPL: {
      companyName: 'Apple Inc.',
      sector: 'Consumer Electronics',
      price: 224.30,
      change: 0.89,
      changePercent: 0.4,
      volume: 41000000,
      avgVolume: 43000000, // normal volume
      volatility: 1.2,
      high: 225.10,
      low: 223.20,
      open: 223.80,
      marketReturn: 0.4,
      sectorReturn: 0.5,
      source: 'Nasdaq Realtime (Mock)',
      freshness: 'LIVE',
      confidence: 0.99,
      observedAt: new Date().toISOString(),
    },
    MSFT: {
      companyName: 'Microsoft Corporation',
      sector: 'Software & Cloud',
      price: 418.60,
      change: 8.62,
      changePercent: 2.1,
      volume: 24500000,
      avgVolume: 18800000, // 1.3x volume
      volatility: 1.1,
      high: 419.80,
      low: 410.50,
      open: 411.00,
      marketReturn: 0.4,
      sectorReturn: 0.8,
      source: 'Nasdaq Realtime (Mock)',
      freshness: 'LIVE',
      confidence: 0.97,
      observedAt: new Date().toISOString(),
    },
    GOOGL: {
      companyName: 'Alphabet Inc.',
      sector: 'Interactive Media',
      price: 164.20,
      change: -0.66,
      changePercent: -0.4,
      volume: 18200000,
      avgVolume: 20100000,
      volatility: 1.4,
      high: 165.40,
      low: 163.80,
      open: 165.00,
      marketReturn: 0.4,
      sectorReturn: 0.2,
      source: 'Nasdaq Realtime (Mock)',
      freshness: 'LIVE',
      confidence: 0.99,
      observedAt: new Date().toISOString(),
    },
    META: {
      companyName: 'Meta Platforms Inc.',
      sector: 'Interactive Media',
      price: 512.80,
      change: 3.05,
      changePercent: 0.6,
      volume: 12400000,
      avgVolume: 11800000,
      volatility: 1.9,
      high: 514.20,
      low: 509.50,
      open: 510.00,
      marketReturn: 0.4,
      sectorReturn: 0.2,
      source: 'Nasdaq Realtime (Mock)',
      freshness: 'LIVE',
      confidence: 0.98,
      observedAt: new Date().toISOString(),
    },
    TSLA: {
      companyName: 'Tesla Inc.',
      sector: 'Automotive & EV',
      price: 214.50,
      change: 7.30,
      changePercent: 3.5,
      volume: 89000000,
      avgVolume: 85000000,
      volatility: 3.2,
      high: 216.00,
      low: 208.00,
      open: 208.50,
      marketReturn: 0.4,
      sectorReturn: -0.5,
      source: 'Consolidated Tape (Stale)',
      freshness: 'STALE', // Stale demo edge case!
      confidence: 0.72,
      observedAt: new Date(Date.now() - 38 * 60 * 1000).toISOString(), // 38 mins ago
    },
    INTC: {
      companyName: 'Intel Corporation',
      sector: 'Semiconductors',
      price: 21.65,
      change: -0.75,
      changePercent: -3.3,
      volume: 54000000,
      avgVolume: 42000000,
      volatility: 2.0,
      high: 22.40,
      low: 21.50,
      open: 22.30,
      marketReturn: 0.4,
      sectorReturn: 1.0,
      source: 'Multi-Source Feed',
      freshness: 'RECENT',
      confidence: 0.65, // Low confidence due to provider conflict
      observedAt: new Date().toISOString(),
      conflictWarning: 'Provider A quote ($21.40) disagrees with Provider B ($21.85). Confidence reduced.',
    },
    AMZN: {
      companyName: 'Amazon.com Inc.',
      sector: 'E-commerce & Cloud',
      price: 178.90,
      change: -3.28,
      changePercent: -1.8,
      volume: 48000000,
      avgVolume: 28000000, // 1.7x volume reversal
      volatility: 1.5,
      high: 184.20, // Opened up at 184.2 (+2.5%), then reversed to 178.90 (-1.8%)
      low: 178.50,
      open: 183.00,
      marketReturn: 0.4,
      sectorReturn: 0.3,
      source: 'Nasdaq Realtime (Mock)',
      freshness: 'LIVE',
      confidence: 0.96,
      observedAt: new Date().toISOString(),
    },
    JPM: {
      companyName: 'JPMorgan Chase & Co.',
      sector: 'Banking & Financials',
      price: 222.40,
      change: 6.26,
      changePercent: 2.9,
      volume: 18500000,
      avgVolume: 9200000, // 2.0x volume sector divergence
      volatility: 1.1,
      high: 223.10,
      low: 216.50,
      open: 216.80,
      marketReturn: 0.4,
      sectorReturn: -0.2, // Sector down -0.2%, JPM up +2.9%
      source: 'NYSE Realtime (Mock)',
      freshness: 'LIVE',
      confidence: 0.98,
      observedAt: new Date().toISOString(),
    },
  };

  public getProviderInfo() {
    return {
      name: 'Deterministic Demo Provider',
      isDemo: true,
    };
  }

  public async getObservation(symbol: string): Promise<MarketObservation> {
    const uppercaseSymbol = symbol.trim().toUpperCase();
    const data = MockMarketDataProvider.mockData[uppercaseSymbol];

    if (!data) {
      // Fallback generator for unknown symbols
      return {
        symbol: uppercaseSymbol,
        companyName: `${uppercaseSymbol} Corp`,
        sector: 'General Market',
        price: 100.0,
        change: 0.5,
        changePercent: 0.5,
        volume: 1000000,
        avgVolume: 1000000,
        volatility: 1.5,
        high: 101.0,
        low: 99.5,
        open: 99.8,
        marketReturn: 0.4,
        sectorReturn: 0.4,
        source: 'Simulated Engine',
        freshness: 'LIVE',
        confidence: 0.9,
        observedAt: new Date().toISOString(),
      };
    }

    return {
      symbol: uppercaseSymbol,
      ...data,
    };
  }

  public async getBatchObservations(symbols: string[]): Promise<MarketObservation[]> {
    return Promise.all(symbols.map((s) => this.getObservation(s)));
  }

  public async getTimeline(
    symbol: string
  ): Promise<Array<{ time: string; price: number; volumeRatio: number; eventNote?: string }>> {
    const sym = symbol.toUpperCase();
    if (sym === 'NVDA') {
      return [
        { time: '09:30 AM', price: 123.50, volumeRatio: 1.0, eventNote: 'Market Open' },
        { time: '10:15 AM', price: 125.10, volumeRatio: 1.4, eventNote: 'Volume begins diverging' },
        { time: '11:05 AM', price: 126.80, volumeRatio: 1.8, eventNote: 'Sector benchmark slows, NVDA accelerates' },
        { time: '12:20 PM', price: 128.00, volumeRatio: 2.2, eventNote: 'Unusual momentum confirmed' },
        { time: '02:45 PM', price: 128.45, volumeRatio: 2.4, eventNote: 'Current peak observation' },
      ];
    }

    if (sym === 'AMD') {
      return [
        { time: '09:30 AM', price: 147.90, volumeRatio: 1.0, eventNote: 'Market Open' },
        { time: '10:30 AM', price: 146.50, volumeRatio: 1.2 },
        { time: '11:45 AM', price: 144.20, volumeRatio: 1.6, eventNote: 'Selling pressure expands' },
        { time: '01:15 PM', price: 142.80, volumeRatio: 1.8, eventNote: '1.8x baseline volume reached' },
        { time: '03:10 PM', price: 142.10, volumeRatio: 1.9, eventNote: 'Down -3.7% vs Sector +1.0%' },
      ];
    }

    if (sym === 'AMZN') {
      return [
        { time: '09:30 AM', price: 183.00, volumeRatio: 1.1, eventNote: 'Opened strong (+2.3%)' },
        { time: '10:15 AM', price: 184.20, volumeRatio: 1.3, eventNote: 'Intraday peak reached' },
        { time: '11:30 AM', price: 181.50, volumeRatio: 1.5, eventNote: 'Direction reversal begins' },
        { time: '01:45 PM', price: 179.20, volumeRatio: 1.6, eventNote: 'Fell below opening price' },
        { time: '03:30 PM', price: 178.90, volumeRatio: 1.7, eventNote: 'Closed -1.8% after morning rally' },
      ];
    }

    // Default timeline template
    const obs = await this.getObservation(sym);
    return [
      { time: '09:30 AM', price: obs.open, volumeRatio: 1.0, eventNote: 'Market Open' },
      { time: '11:30 AM', price: (obs.open + obs.price) / 2, volumeRatio: 0.9 },
      { time: '03:30 PM', price: obs.price, volumeRatio: obs.volume / obs.avgVolume, eventNote: 'Latest state' },
    ];
  }
}
