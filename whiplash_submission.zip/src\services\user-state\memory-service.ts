import { AttentionLevel, UserLastSeenState } from '../market-data/types';

export class UserMemoryService {
  // Map key: `${userId}_${symbol}`
  private static userMemoryStore: Map<string, UserLastSeenState> = new Map();

  /**
   * Fetches the user's last observed baseline for a symbol.
   */
  public static getUserLastSeen(userId: string, symbol: string): UserLastSeenState | undefined {
    const key = `${userId}_${symbol.toUpperCase()}`;
    return this.userMemoryStore.get(key);
  }

  /**
   * Updates user memory state when user observes or dismisses a story.
   */
  public static markAsSeen(
    userId: string,
    symbol: string,
    price: number,
    volume: number,
    score: number,
    attention: AttentionLevel,
    timestampOverride?: string
  ): UserLastSeenState {
    const sym = symbol.toUpperCase();
    const key = `${userId}_${sym}`;

    const newState: UserLastSeenState = {
      symbol: sym,
      lastSeenTimestamp: timestampOverride || new Date().toISOString(),
      lastSeenPrice: price,
      lastSeenVolume: volume,
      lastSeenScore: score,
      lastSeenAttention: attention,
    };

    this.userMemoryStore.set(key, newState);
    return newState;
  }

  /**
   * Sets initial demo baselines representing "Yesterday's session" so returning users immediately see realistic deltas.
   */
  public static seedDemoBaselines(userId: string): void {
    const yesterday = new Date(Date.now() - 22 * 60 * 60 * 1000).toISOString();

    const baselines: Array<[string, number, number, number, AttentionLevel]> = [
      ['NVDA', 122.57, 32000000, 25, 'NORMAL'], // yesterday NVDA was normal at $122.57
      ['AMD', 147.55, 30000000, 20, 'NORMAL'],  // yesterday AMD was normal at $147.55
      ['AAPL', 223.41, 40000000, 15, 'NORMAL'], // yesterday AAPL was $223.41
      ['MSFT', 409.98, 18000000, 30, 'NORMAL'], // yesterday MSFT was $409.98
      ['TSLA', 207.20, 80000000, 20, 'NORMAL'],
      ['INTC', 22.40, 40000000, 18, 'NORMAL'],
      ['AMZN', 182.18, 26000000, 22, 'NORMAL'],
      ['JPM', 216.14, 9000000, 15, 'NORMAL'],
    ];

    for (const [sym, price, volume, score, att] of baselines) {
      const key = `${userId}_${sym}`;
      if (!this.userMemoryStore.has(key)) {
        this.userMemoryStore.set(key, {
          symbol: sym,
          lastSeenTimestamp: yesterday,
          lastSeenPrice: price,
          lastSeenVolume: volume,
          lastSeenScore: score,
          lastSeenAttention: att,
        });
      }
    }
  }

  public static clear(): void {
    this.userMemoryStore.clear();
  }
}
