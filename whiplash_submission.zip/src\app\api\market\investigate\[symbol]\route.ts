import { NextRequest, NextResponse } from 'next/server';
import { ChangeDetectionEngine } from '@/services/change-detection/engine';
import { MockMarketDataProvider } from '@/services/market-data/mock-provider';
import { DataReconciler } from '@/services/market-data/reconciler';
import { UserMemoryService } from '@/services/user-state/memory-service';

const provider = new MockMarketDataProvider();

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ symbol: string }> }
) {
  try {
    const { symbol } = await params;
    const cleanSymbol = symbol.toUpperCase();
    const userId = 'user_demo_1';

    const rawObs = await provider.getObservation(cleanSymbol);
    const obs = DataReconciler.reconcile([rawObs]);
    const lastSeen = UserMemoryService.getUserLastSeen(userId, cleanSymbol);
    const timeline = await provider.getTimeline(cleanSymbol);

    const story = ChangeDetectionEngine.analyze(obs, lastSeen, timeline);

    return NextResponse.json(story);
  } catch (error: any) {
    return NextResponse.json(
      { error: 'Failed to investigate symbol', message: error?.message || 'Unknown error' },
      { status: 500 }
    );
  }
}
