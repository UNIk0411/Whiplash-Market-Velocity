import { NextRequest, NextResponse } from 'next/server';
import { SnapshotService } from '@/services/snapshot/snapshot-service';
import { UserMemoryService } from '@/services/user-state/memory-service';
import { WatchlistService } from '@/services/watchlist/watchlist-service';

export async function POST(request: NextRequest) {
  try {
    const userId = 'user_demo_1';
    UserMemoryService.clear();
    UserMemoryService.seedDemoBaselines(userId);
    SnapshotService.clear();
    WatchlistService.resetToDefaults();

    return NextResponse.json({ success: true, message: 'Demo environment reset successfully.' });
  } catch (error: any) {
    return NextResponse.json({ error: 'Failed to reset demo environment' }, { status: 500 });
  }
}
